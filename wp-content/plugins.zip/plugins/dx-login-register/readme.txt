﻿=== dx-login-register ===
Contributors: daxiawp
Donate link: http://www.daxiawp.com
Tags: login,register,sign,sign up,captcha, login register, custom login, custom register, login captcha, register captcha
Requires at least: 3.1
Tested up to: 3.8
Stable tag: 3.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Custom login and registration. 自定义登录注册。

== Description ==

Sign custom page content, custom password, authentication code detection, login redirection function, etc.

自定义登录注册页面内容，自定义密码，验证码检测，登录重定向等功能。

详情请浏览：[http://www.daxiawp.com/dx-login-register.html](http://www.daxiawp.com/dx-login-register.html)

== Installation ==


== Frequently asked questions ==



== Screenshots ==

1. Options
2. Options
3. Login
4. Register

== Changelog ==

= 1.0.1 =
* Fix login logo size for wordpress 3.8+. 修复wordpress 3.8+ 版本的登陆页面logo大小。

= 1.0.0 =
* Sign custom page content, custom password, authentication code detection, login redirection function, etc. 自定义登录注册页面内容，自定义密码，验证码检测，登录重定向等功能。

== Upgrade notice ==



== Arbitrary section 1 ==

