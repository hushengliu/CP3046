<?php

require( 'class-captcha.php' );

$login_captcha = new Dxlore_Captcha();
$login_captcha->do_img();